fahrenheit = float(input("Digite os graus em Fahrenheit: "))
celsius = 5 * (fahrenheit - 32) / 9
print(f"Celsius: {celsius}ºC")